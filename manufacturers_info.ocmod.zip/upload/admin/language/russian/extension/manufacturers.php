<?php
$_['heading_title']  						= 'Информация о производителях';
$_['text_manufacturers']              		= 'Производители';


$_['text_input_XML_link_label']				= 'Ссылка на XML';
$_['text_save_link']						= 'Сохранить ссылку';
$_['text_load_information']					= 'Обновить информацию';
$_['text_loaded_information']				= 'Информация о производителях загружена';


$_['text_manufacturer_name']				= 'Наименование производителя';
$_['text_manufacturer_logo']				= 'Логотип';
$_['text_manufacturer_description']			= 'Описание';


$_['text_success']   						= 'Настройки успешно изменены!';
$_['text_edit']      						= 'Настройки модуля';

