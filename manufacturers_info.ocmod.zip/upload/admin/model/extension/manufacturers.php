<?php
class ModelExtensionManufacturers extends Model {

  // Запись настроек в базу данных
  public function SaveSettings() {
    $this->load->model('setting/setting');
    $this->model_setting_setting->editSetting('XML_link', $this->request->post);
  }

  // Загрузка настроек из базы данных
  public function LoadSettings() {
    return $this->config->get('XML_link');
  }


  public function LoadManufaturersInformation(){
	$manufacturers = Array();
	$xmlURL = $this->config->get('XML_link');

	$xml = simplexml_load_file($xmlURL);

	foreach ($xml->tyre->marka as $item) {
	    $manufacturers["$item->name"] = [
	        'logo' => "$item->logo",
	        'description' => "$item->html",
	        // 'description' => iconv('windows-1251', 'utf-8', file_get_contents("$item->html")),
	    ];
	}

	return $manufacturers;
  }

}
