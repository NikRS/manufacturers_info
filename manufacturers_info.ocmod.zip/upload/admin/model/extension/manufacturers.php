<?php
class ModelExtensionManufacturers extends Model {


  public function SaveSettings() {
    $this->load->model('setting/setting');
    $this->model_setting_setting->editSetting('XML_link', $this->request->post);
  }


  public function LoadSettings() {
    return $this->config->get('XML_link');
  }


  public function LoadManufaturersInformation(){
	$manufacturers = Array();
	$xmlURL = $this->config->get('XML_link');

	$xml = simplexml_load_file($xmlURL);

	foreach ($xml->tyre->marka as $item) {
	    $manufacturers["$item->name"] = [
	        'logo' => "$item->logo",
	        'description' => "$item->html",
	        // 'description' => iconv('windows-1251', 'utf-8', file_get_contents("$item->html")),
	    ];
	}

	return $manufacturers;
  }


	public function addManufacturers($manufacturers_array) {

		$store_id = 0;
		$sort_order = 0;
		$language_id = 1; // 1 - русский, 2 - английский

		foreach ($manufacturers_array as $name => $description) {
			$this->db->query("INSERT INTO " . DB_PREFIX 
				. "manufacturer SET name = '" . $this->db->escape($name) 
				. "', sort_order = '" . (int)$sort_order
				. "'");
			
				$manufacturer_id = $this->db->getLastId();

			if ($description["logo"] != '') {
				$description["logo"] = $this->saveManufacturerLogo($description["logo"], $name);
			}
			$this->db->query("UPDATE " . DB_PREFIX 
				. "manufacturer SET image = '" . $this->db->escape($description["logo"]) 
				. "' WHERE manufacturer_id = '" . (int)$manufacturer_id 
				. "'");

			$this->db->query("INSERT INTO " . DB_PREFIX 
				. "manufacturer_description SET manufacturer_id = '" . (int)$manufacturer_id 
				. "', language_id = '" . (int)$language_id 
				. "', name = '" . $this->db->escape($name) 
				. "', description = '" . $this->db->escape($description["description"]) 
				. "'");

			$this->db->query("INSERT INTO " . DB_PREFIX 
				. "manufacturer_to_store SET manufacturer_id = '" . (int)$manufacturer_id 
				. "', store_id = '" . (int)$store_id 
				. "'");

			$this->cache->delete('manufacturer');
		}
	}


	private function saveManufacturerLogo($url, $name){
		$dir_path = '../image/catalog/manufacturers/';
		$file_name = $name . substr($url, strripos($url, '.'));

		file_put_contents($dir_path . $file_name, file_get_contents($url));

		return substr($dir_path, 9) . $file_name;
	}


}
