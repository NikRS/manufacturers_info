<?php
class ControllerExtensionManufacturers extends Controller {

  public function index() {

    // Загружаем "модель" модуля
    $this->load->model('extension/manufacturers');


    // Загружаем настройки через метод "модели"
    $data = array();
    $data['XML_link'] = $this->model_extension_manufacturers->LoadSettings();
    // Загружаем языковой файл
    $data += $this->load->language('extension/manufacturers');
    // Загружаем "хлебные крошки"
    $data += $this->GetBreadCrumbs();

    // Кнопки действий
    $data['action'] = $this->url->link('extension/manufacturers', 'token=' . $this->session->data['token'], true);
    $data['load'] = $this->url->link('extension/manufacturers', 'token=' . $this->session->data['token'] . '&load_manufacturers_information=true', true);
    $data['cancel'] = $this->url->link('common/dashboard', 'token=' . $this->session->data['token'] . '&type=module', true);
    // Загрузка шаблонов для шапки, колонки слева и футера
    $data['header'] = $this->load->controller('common/header');
    $data['column_left'] = $this->load->controller('common/column_left');
    $data['footer'] = $this->load->controller('common/footer');


    // Сохранение настроек модуля, когда пользователь нажал "Записать"
    if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
      // Вызываем метод "модели" для сохранения настроек
      $this->model_extension_manufacturers->SaveSettings();
      // Выходим из настроек с выводом сообщения
      $this->response->redirect($this->url->link('extension/manufacturers', 'token=' . $this->session->data['token'] . '&type=module' . '&msg=success_save', true));
    }

    if (isset($_GET['load_manufacturers_information'])) {
      $data['manufacturers'] = $this->model_extension_manufacturers->LoadManufaturersInformation();
      $this->model_extension_manufacturers->addManufacturers($data['manufacturers']);
      if (count($data['manufacturers']) > 1) {
        $data["success_message"] =  "Импорт успешно завершен. Добвалено " . count($data['manufacturers']) . " производителей.";
      }
    }

    // Выводим в браузер шаблон
    $this->response->setOutput($this->load->view('extension/manufacturers.tpl', $data));

  }

  // Хлебные крошки
  private function GetBreadCrumbs() {
    $data = array(); $data['breadcrumbs'] = array();
    $data['breadcrumbs'][] = array(
      'text' => $this->language->get('text_home'),
      'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
    );
    $data['breadcrumbs'][] = array(
      'text' => $this->language->get('heading_title'),
      'href' => $this->url->link('extension/manufacturers', 'token=' . $this->session->data['token'], true)
    );
    return $data;
  }

}
?>